<?php $__env->startSection('template_title'); ?>
<?php echo e($empleado->nombre ?? 'Show Empleado'); ?> |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            INFORMACIÓN DE EMPLEADO
                        </span>


                        <div class="float-right">
                            <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-warning btn-sm float-right"
                                data-placement="left">
                                <i class="fas fa-arrow-left"></i>
                                Volver
                            </a>
                        </div>

                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <div class="form-group">
                                <strong>Nombre:</strong>
                                <?php echo e($empleado->nombre); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Cédula:</strong>
                                <?php echo e($empleado->cedula); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Dirección:</strong>
                                <?php echo e($empleado->direccion); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Teléfono:</strong>
                                <?php echo e($empleado->telefono); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Fecha Nacimiento:</strong>
                                <?php echo e($empleado->fecnacimiento); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Email:</strong>
                                <?php echo e($empleado->email); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Cargo:</strong>
                                <?php echo e($empleado->cargoempleado->nombre); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Estado:</strong>
                                <?php if($empleado->estado): ?>
                                <span class="badge bg-success">ACTIVO</span>
                                <?php else: ?>
                                <span class="badge bg-danger">INACTIVO</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <div class="form-group">
                                <strong>Foto de Perfil:</strong><br>
                                <img src="<?php echo e(Storage::url($empleado->avatar)); ?>" width="100px" class="img-thumbnail" style="float: left">
                            </div>
                        </div>
                    </div>










                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/empleado/show.blade.php ENDPATH**/ ?>