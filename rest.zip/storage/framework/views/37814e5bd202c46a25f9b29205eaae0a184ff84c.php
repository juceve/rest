<div class="row">
    <div class="col-12 col-md-6 form-group">
        <form wire:submit.prevent="save">
            <div class="mb-3">
                <label for="formFile" class="form-label">Icono de la empresa</label>
                <input class="form-control" type="file" id="formFile" wire:model="photo">
            </div>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="fs-6 text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
        </form>
    </div>
    <div class="col-12 col-md-6">
        <?php if($photo): ?>
        
        <img src="<?php echo e($photo->temporaryUrl()); ?>" width="200px">
        
        <?php endif; ?>
    </div>

</div><?php /**PATH C:\xampp\htdocs\rest\resources\views/livewire/upload-pics.blade.php ENDPATH**/ ?>