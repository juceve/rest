

<?php $__env->startSection('template_title'); ?>
Editar Roles Usuarios | 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        <div style="display: flex; justify-content: space-between; align-items: center;">

            <span id="card_title">
                ASIGNACIÓN DE ROLES
            </span>

            
            <div class="float-right">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-warning btn-sm float-right"
                    data-placement="left">
                    <i class="fas fa-arrow-left"></i>
                    Volver
                </a>
            </div>
            
        </div>
    </div>
    <div class="card-body">
        <p class="h5">Nombre: </p>
        <p class="form-control"><?php echo e($user->name); ?></p>
        <hr>
        <?php echo Form::model($user, ['route'=>['users.update', $user], 'method' => 'put']); ?>

        <h2 class="h5">Listado de Roles</h2>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <label for="">
                <?php echo Form::checkbox('roles[]', $role->id, null, ['class'=>'mr-1']); ?>

                <?php echo e($role->name); ?>

            </label>
        </div>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo Form::submit('Asignar Rol', ['class' => 'btn btn-primary mt-2']); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/user/edit.blade.php ENDPATH**/ ?>