<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group mb-3">
            <?php echo e(Form::label('nombre')); ?>

            <?php echo e(Form::text('nombre', $tipopago->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group mb-3">
            <?php echo e(Form::label('abreviatura')); ?>

            <?php echo e(Form::text('abreviatura', $tipopago->abreviatura, ['class' => 'form-control' . ($errors->has('abreviatura') ? ' is-invalid' : ''), 'placeholder' => 'Abreviatura'])); ?>

            <?php echo $errors->first('abreviatura', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>    
</div><?php /**PATH C:\xampp\htdocs\rest\resources\views/tipopago/form.blade.php ENDPATH**/ ?>