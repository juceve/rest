<?php $__env->startSection('template_title'); ?>
    <?php echo e($estudiante->name ?? 'Show Estudiante'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                    INFORMACIÓN DEL ESTUDIANTE
                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('estudiantes.index')); ?>" class="btn btn-secondary btn-sm float-right"  data-placement="left">
                                  <i class="fas fa-arrow-left"></i>
                                  Volver
                                </a>
                              </div>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group mb-3">
                            <strong>Código:</strong>
                            <?php echo e($estudiante->codigo); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Nombre:</strong>
                            <?php echo e($estudiante->nombre); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Cédula:</strong>
                            <?php echo e($estudiante->cedula); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Teléfono:</strong>
                            <?php echo e($estudiante->telefono); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Tutor:</strong>
                            <?php echo e($estudiante->tutore->nombre); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Curso:</strong>
                            <?php echo e($estudiante->curso->nombre.' - '.$estudiante->curso->nivelcurso->nombre); ?>

                        </div>
                        <div class="form-group mb-3">
                            <strong>Establecimiento:</strong>
                            <?php echo e($estudiante->curso->nivelcurso->sucursale->nombre); ?>

                        </div>
                        <div class="form-group mb-3 d-none">
                            <strong>Verificado:</strong>
                            <?php echo e($estudiante->verificado); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/estudiante/show.blade.php ENDPATH**/ ?>