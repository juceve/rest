<?php $__env->startSection('template_title'); ?>
Estudiante
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            LISTADO DE ESTUDIANTES
                        </span>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estudiantes.create')): ?>
                        <div class="float-right">
                            <a href="<?php echo e(route('estudiantes.create')); ?>" class="btn btn-secondary btn-sm float-right"
                                data-placement="left">
                                <i class="fas fa-plus"></i>
                                Nuevo
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover dataTable">
                            <thead class="thead">
                                <tr>
                                    <th>CÓDIGO</th>
                                    <th>NOMBRE</th>
                                    <th>TUTOR</th>
                                    <th>CURSO</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($estudiante->codigo); ?></td>
                                    <td><?php echo e($estudiante->nombre); ?></td>
                                    <td><?php echo e($estudiante->tutore->nombre); ?></td>
                                    <td><?php echo e($estudiante->curso->nombre.' - '.$estudiante->curso->nivelcurso->nombre); ?>

                                    </td>
                                    <td align="right">
                                        <form action="<?php echo e(route('estudiantes.destroy',$estudiante->id)); ?>" method="POST"
                                            class="delete">
                                            <a class="btn btn-sm btn-primary "
                                                href="<?php echo e(route('estudiantes.show',$estudiante->id)); ?>" title="Info"><i
                                                    class="fa fa-fw fa-eye"></i></a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estudiantes.edit')): ?>
                                            <a class="btn btn-sm btn-success"
                                                href="<?php echo e(route('vinculosestudiantes',$estudiante->tutore_id)); ?>"
                                                title="Editar"><i class="fa fa-fw fa-edit"></i></a>
                                            <?php endif; ?>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estudiantes.destroy')): ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                title="Eliminar de la BD"><i class="fa fa-fw fa-trash"></i></button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo $estudiantes->links(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/estudiante/index.blade.php ENDPATH**/ ?>