<?php return array (
  'clientes.tutores' => 'App\\Http\\Livewire\\Clientes\\Tutores',
  'clientes.vinculosestudiantes' => 'App\\Http\\Livewire\\Clientes\\Vinculosestudiantes',
  'cursos.cursos' => 'App\\Http\\Livewire\\Cursos\\Cursos',
  'settings.areas' => 'App\\Http\\Livewire\\Settings\\Areas',
  'settings.cargoempleados' => 'App\\Http\\Livewire\\Settings\\Cargoempleados',
  'settings.estadopagos' => 'App\\Http\\Livewire\\Settings\\Estadopagos',
  'settings.nivelcursos' => 'App\\Http\\Livewire\\Settings\\Nivelcursos',
  'settings.settings' => 'App\\Http\\Livewire\\Settings\\Settings',
  'settings.tipopagos' => 'App\\Http\\Livewire\\Settings\\Tipopagos',
  'sucursales' => 'App\\Http\\Livewire\\Sucursales',
  'upload-pics' => 'App\\Http\\Livewire\\UploadPics',
);