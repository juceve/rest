

<?php $__env->startSection('template_title'); ?>
Componentes de Inicio |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between w-100 flex-wrap">
    <div class="mb-3 mb-lg-0">
        <h1 class="h4">Componentes de Inicio</h1>
    </div>


</div>
<div class="row">
    
    <div class="col-xs-12 col-xl-6 mb-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('settings.tipopagos')->html();
} elseif ($_instance->childHasBeenRendered('RXHW4Ys')) {
    $componentId = $_instance->getRenderedChildComponentId('RXHW4Ys');
    $componentTag = $_instance->getRenderedChildComponentTagName('RXHW4Ys');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RXHW4Ys');
} else {
    $response = \Livewire\Livewire::mount('settings.tipopagos');
    $html = $response->html();
    $_instance->logRenderedChild('RXHW4Ys', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/setting/index.blade.php ENDPATH**/ ?>