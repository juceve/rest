<div>
    <?php $__env->startSection('template_title'); ?>
    Sucursales |
    <?php $__env->stopSection(); ?>

    <div class="card ">
        <div class="card-header bg-primary text-white">
            <div style="display: flex; justify-content: space-between; align-items: center;">

                <span id="card_title">
                    SUCURSALES VINCULADAS - <strong><?php echo e($empresa->razonsocial); ?></strong>
                </span>
                
                <div class="float-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursales.create')): ?>
                    <button class="btn btn-info btn-sm float-right" data-placement="left" data-bs-toggle="modal"
                        data-bs-target="#modalNuevo">
                        <i class="fas fa-plus"></i>
                        Nuevo
                    </button>
                    <?php endif; ?>
                    <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-secondary btn-sm">
                        <i class="fas fa-arrow-left"></i>
                        Volver
                    </a>
                </div>
                

            </div>
        </div>
        <div class="card-body">

            <div class="table-responsive container-fluid ">
                <form class="form-horizontal mb-3">
                    <div class="form-group row">
                        <div class="col-md-2 text-md-right col-xl-1 text-lg-left">
                            <label for="form-label">Ordenar</label>

                        </div>
                        <div class="col-3 col-sm-2  col-md-2 col-lg-2 col-xl-1">
                            <select class="form-control form-control-sm" wire:model="paginate" style="width: 100%">
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                            </select>
                        </div>
                        <div class="col-2 col-xl-5"></div>
                        <label class="col-md-2 col-xl-1 form-label text-lg-right">Buscar:</label>
                        <div class="col-md-4 ">
                            <input type="search" class="form-control form-control-sm"
                                placeholder="Buscar por nombre o tipo" wire:model="search" style="width: 100%">
                        </div>


                    </div>
                </form>
                <table class="table table-hover  mb-3">

                    <thead class="thead">
                        <tr class="table-primary">
                            <th style="cursor: pointer;" wire:click="order('id')">
                                ID
                                
                                <?php if($sort == 'id'): ?>
                                <?php if($direction == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                                <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>

                            <th style="cursor: pointer;" wire:click="order('nombre')">
                                NOMBRE
                                
                                <?php if($sort == 'nombre'): ?>
                                <?php if($direction == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                                <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>

                            </th>
                            <th style="cursor: pointer;" wire:click="order('tipo')">
                                TIPO
                                
                                <?php if($sort == 'tipo'): ?>
                                <?php if($direction == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                                <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>

                            <th style="cursor: pointer;" wire:click="order('estado')">
                                Estado
                                
                                <?php if($sort == 'estado'): ?>
                                <?php if($direction == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                                <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>
                            <th style="width: 150px"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($sucursales->count() > 0): ?>
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sucursale->id); ?></td>
                            <td><?php echo e($sucursale->nombre); ?></td>
                            <td><?php echo e($sucursale->tipo); ?></td>
                            <td>
                                <?php if($sucursale->estado): ?>
                                <span class="badge bg-success">ACTIVO</span>
                                <?php else: ?>
                                <span class="badge bg-danger">INACTIVO</span>
                                <?php endif; ?>
                            </td>
                            <td>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursales.edit')): ?>
                                <button class="btn btn-sm btn-info" title="Editar" onclick="editar(<?php echo e($sucursale->id); ?>)">
                                    <i class="fa fa-fw fa-edit "></i>
                                </button>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursales.disable')): ?>
                                <?php if($sucursale->estado): ?>
                                <button type="submit" class="btn btn-warning btn-sm disable" title="Desactivar"
                                    onclick="desactivar(<?php echo e($sucursale->id); ?>)"><i class="fas fa-power-off"></i></button>
                                <?php else: ?>
                                <button type="submit" class="btn btn-success btn-sm disable" title="Activar"
                                    onclick="desactivar(<?php echo e($sucursale->id); ?>)"><i class="fas fa-power-off"></i></button>
                                <?php endif; ?>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursales.destroy')): ?>
                                <button type="submit" class="btn btn-danger btn-sm delete" title="Eliminar"
                                    onclick="eliminar(<?php echo e($sucursale->id); ?>)"><i class="fa fa-fw fa-trash "></i></button>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">
                                <span>No se encontraron registros.</span>
                            </td>
                        </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
                <div style="float: right">
                    <?php echo e($sucursales->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div wire:ignore class="modal fade" id="modalNuevo" tabindex="-1" aria-labelledby="modalNuevoLabel"
        aria-hidden="true" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalNuevoLabel">Registro de Sucursal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        wire:click="resetear"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-4 mb-3">
                            <label for="">NOMBRE</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="nombre" class="form-control">
                        </div>
                        <div class="col-4 mb-3">
                            <label for="">DIRECCION</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="direccion" class="form-control">
                        </div>
                        <div class="col-4 mb-3">
                            <label for="">TELEFONO</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="telefono" class="form-control">
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                        wire:click="resetear">Cerrar</button>
                    <button type="button" class="btn btn-primary" wire:click="save">Registrar</button>
                </div>
            </div>
        </div>
    </div>

    <div wire:ignore class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="modalEditarLabel"
        aria-hidden="true" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalNuevoLabel">Editar Sucursal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        wire:click="resetear"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-4 mb-3">
                            <label for="">NOMBRE</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="nombre" class="form-control">
                        </div>
                        <div class="col-4 mb-3">
                            <label for="">DIRECCION</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="direccion" class="form-control">
                        </div>
                        <div class="col-4 mb-3">
                            <label for="">TELEFONO</label>
                        </div>
                        <div class="col-8 mb-3">
                            <input type="text" wire:model.defer="telefono" class="form-control">
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                        wire:click="resetear">Cerrar</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal"
                        wire:click="update">Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
    <script>
        Livewire.on('success', message =>{
            $('#modalNuevo').hide();
            Swal.fire(
            'Excelente!',
            message,
            'success'
            )
        });


    function desactivar(id) {
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
        })

        swalWithBootstrapButtons.fire({
            title: 'Modificar Estado!',
            text: "Esta seguro de realizar la operación?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Si, continuar!',
            cancelButtonText: 'No, cancelar!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('desactivar',id);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire(
                    'Operación cancelada',
                    'No se modificó ningún registro',
                    'error'
                )
            }
        })
    }

    function eliminar(id) {    
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
        })

        swalWithBootstrapButtons.fire({
            title: 'Elminar de la Base de Datos!',
            text: "Esta seguro de realizar la operación?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Si, continuar!',
            cancelButtonText: 'No, cancelar!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('eliminar',id);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire(
                    'Operación cancelada',
                    'No se modificó ningún registro',
                    'error'
                )
            }
        });
    }

    function editar(id){
        Livewire.emit('editar',id);
        $('#modalEditar').modal('show');
    }
    </script>
    <?php $__env->stopSection(); ?>

</div><?php /**PATH C:\xampp\htdocs\rest\resources\views/livewire/sucursales.blade.php ENDPATH**/ ?>