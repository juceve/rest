<?php $__env->startSection('template_title'); ?>
    <?php echo e($tutore->name ?? 'Show Tutore'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Tutore</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('tutores.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($tutore->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cedula:</strong>
                            <?php echo e($tutore->cedula); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($tutore->telefono); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/tutore/show.blade.php ENDPATH**/ ?>