<?php $__env->startSection('template_title'); ?>
Datos Empresa |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div class="row">
                        <div class="col-7">
                            <span class="card-title">Datos de la Empresa</span>
                        </div>
                        <div class="col-5 text-end">
                            <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-warning btn-sm" ><i
                                    class="fas fa-arrow-left"></i> Volver</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">


                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Razon social:</strong>
                                <?php echo e($empresa->razonsocial); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            
                            <span class="align-middle"><img src="<?php echo e(Storage::url($empresa->avatar)); ?>" alt="" height="35px"></span>
                            
                        </div>
                        <hr>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Dirección:</strong>
                                <?php echo e($empresa->direccion); ?>

                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Teléfono:</strong>
                                <?php echo e($empresa->telefono); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Email:</strong>
                                <?php echo e($empresa->email); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>NIT:</strong>
                                <?php echo e($empresa->nit); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Responsable:</strong>
                                <?php echo e($empresa->responsable); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Telefono Resp.:</strong>
                                <?php echo e($empresa->telefono_responsable); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group mb-2">
                                <strong>Estado:</strong>
                                <?php if($empresa->estado): ?>
                                        <span class="badge bg-success">ACTIVO</span>
                                        <?php else: ?>
                                        <span class="badge bg-danger">INACTIVO</span>
                                        <?php endif; ?>
                            </div>
                        </div>
                    </div>





                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/empresa/show.blade.php ENDPATH**/ ?>