

<?php $__env->startSection('template_title'); ?>
REGISTRAR ROL
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        <div style="display: flex; justify-content: space-between; align-items: center;">

            <span id="card_title">
                FORMULARIO DE REGISTRO
            </span>
            
            <div class="float-right">
                <a href="javascript:void(0)" onclick="history.back()" class="btn btn-warning btn-sm float-right"
                    data-placement="left">
                    <i class="fas fa-arrow-left"></i>
                    Volver
                </a>
            </div>
            

        </div>
    </div>
    <div class="card-body">
        <?php echo Form::open(['route'=>'roles.store']); ?>

        <?php echo $__env->make('roles.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::submit('Crear rol', ['class'=>'btn btn-primary px-5']); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/roles/create.blade.php ENDPATH**/ ?>