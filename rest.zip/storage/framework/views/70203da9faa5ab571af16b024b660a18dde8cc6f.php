<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('nombre')); ?>

                    <?php echo e(Form::text('nombre', $empleado->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? '
                    is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('cédula')); ?>

                    <?php echo e(Form::text('cedula', $empleado->cedula, ['class' => 'form-control' . ($errors->has('cedula') ? '
                    is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('cedula', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('dirección')); ?>

                    <?php echo e(Form::text('direccion', $empleado->direccion, ['class' => 'form-control' .
                    ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('teléfono')); ?>

                    <?php echo e(Form::text('telefono', $empleado->telefono, ['class' => 'form-control' .
                    ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('Fec. Nacimiento')); ?>

                    <?php echo e(Form::date('fecnacimiento', $empleado->fecnacimiento, ['class' => 'form-control' .
                    ($errors->has('fecnacimiento') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('fecnacimiento', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <?php if(is_null($empleado->email)): ?>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('email')); ?>

                    <?php echo e(Form::email('email', $empleado->email, ['class' => 'form-control' . ($errors->has('email') ? '
                    is-invalid' : ''), 'placeholder' => '' ])); ?>

                    <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <?php endif; ?>

            <div class="col-12 col-md-6 mb-3">
                <?php echo e(Form::label('Sucursal asignada')); ?>

                <?php echo Form::select('sucursale_id', $sucursales, $empleado->empresa_id?$empleado->empresa_id:null,
                ['class'=>'form-select','placeholder'=>'Seleccione una Sucursal','required']); ?>

                <?php echo $errors->first('sucursale_id', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="form-group">
                    <?php echo e(Form::label('Cargo')); ?>

                    <?php echo Form::select('cargoempleado_id', $cargos, $empleado->cargoempleado_id,
                    ['class'=>'form-select','placeholder'=>'Seleccione un Cargo','required']); ?>

                    <?php echo $errors->first('cargoempleado_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="mb-3">
                    <label for="avatar" class="form-label">Foto de Perfil</label>
                    <input class="form-control" type="file" id="avatar" name="avatar" accept="image/*"
                        onchange="preview_image(event)">
                </div>
                <div class="mb-3">
                    <img id="output_image" style="max-height: 100px" />
                </div>
            </div>
            <div class="col-12 col-md-6 mb-3 d-none">
                <div class="form-group">
                    <?php echo e(Form::label('user_id')); ?>

                    <?php echo e(Form::text('user_id', $empleado->user_id, ['class' => 'form-control' . ($errors->has('user_id') ?
                    ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

                    <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 mb-3 d-none">
                <div class="form-group">
                    <?php echo e(Form::label('estado')); ?>

                    <?php echo e(Form::text('estado', $empleado->estado?$empleado->estado:true, ['class' => 'form-control' .
                    ($errors->has('estado') ? '
                    is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rest\resources\views/empleado/form.blade.php ENDPATH**/ ?>