<div class="form-group">
    <?php echo Form::label('name', 'Nombre'); ?>

    <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <h2 class="h3 mt-2">Lista de Permisos</h2>
    <?php
    $grupo="";
    ?>
    <div class=col-xxl-8 table-responsive ">

        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($grupo!=$permission->grupo): ?>
        <?php
        $grupo = $permission->grupo

        ?>
        <?php if($grupo!=""): ?>
        </tr>
        </tbody>
        </table>
        <table class="table table-sm table-striped mb-4">
            <tbody>

                <?php endif; ?>
                <tr>
                    <td style="width: 300px"><?php echo e($permission->grupo); ?></td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <?php echo Form::checkbox('permissions[]', $permission->id, null, ['class'=>'mr-1']); ?>

                            <?php echo e($permission->descripcion); ?>

                        </label>
                    </td>
                    <?php else: ?>
                    <td>
                        <label>
                            <?php echo Form::checkbox('permissions[]', $permission->id, null, ['class'=>'mr-1']); ?>

                            <?php echo e($permission->descripcion); ?>

                        </label>
                    </td>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>





<?php /**PATH C:\xampp\htdocs\rest\resources\views/roles/form.blade.php ENDPATH**/ ?>