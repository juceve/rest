@extends('layouts.app')

@section('template_title')
    DATOS DEL ROL
@endsection

@section('content')
<div class="card">
    <div class="card-header">

    </div>
    <div class="card-body">
        
    </div>
</div>
@endsection