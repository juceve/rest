<div>
    <div class="card">
        <div class="card-header bg-info text-white">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span id="card_title">
                    LISTADO DE CURSOS
                </span>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cursos.create')): ?>
                <div class="float-right">
                    <button class="btn btn-primary btn-sm" data-placement="left" data-bs-toggle="modal"
                        data-bs-target="#modalCurso" onclick="store()">
                        <i class="fas fa-plus"></i>
                        Nuevo
                    </button>
                </div>
                <?php endif; ?>

            </div>
        </div>
        <div class="card-body">
            <div class="mb-3" style="overflow-x: hidden;">
                <form class="form-horizontal mb-3">
                    <div class="form-group row">
                        <div class="col-md-2 text-md-right col-xl-1 text-lg-left">
                            <label for="form-label">Ordenar</label>
                        </div>
                        <div class="col-3 col-sm-2  col-md-2 col-lg-2 col-xl-1">
                            <select class="form-control form-control-sm" wire:model="paginate" style="width: 100%">
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                            </select>
                        </div>
                        <div class="col-2 col-xl-5"></div>
                        <label class="col-md-2 col-xl-1 form-label text-lg-right">Buscar:</label>
                        <div class="col-md-4 ">
                            <input type="search" class="form-control form-control-sm" placeholder="Buscar por nombre"
                                wire:model="search" style="width: 100%">
                        </div>


                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table table-stripped table-sm">
                        <thead class="thead">
                            <tr class="table-primary">
                                <th style="cursor: pointer;" wire:click="order('id')">
                                    ID
                                    
                                    <?php if($sort == 'id'): ?>
                                    <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>

                                <th style="cursor: pointer;" wire:click="order('nombre')">
                                    NOMBRE
                                    
                                    <?php if($sort == 'nombre'): ?>
                                    <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>

                                </th>
                                <th style="cursor: pointer;" wire:click="order('nivelcurso_id')">
                                    NIVEL
                                    
                                    <?php if($sort == 'nivelcurso_id'): ?>
                                    <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th style="width: 150px"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->nombre); ?></td>
                                <td><?php echo e($item->nivelcurso->nombre); ?></td>
                                <td align="right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cursos.edit')): ?>
                                    <button class="btn btn-warning btn-sm e" title="Editar" onclick="update()"
                                        wire:click="edit(<?php echo e($item->id); ?>)" data-bs-toggle="modal"
                                        data-bs-target="#modalCurso">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cursos.destroy')): ?>
                                    <button class="btn btn-danger btn-sm text-white" title="Eliminar"
                                        onclick="eliminar(<?php echo e($item->id); ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>



                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <div style="float: right">
                <?php echo e($cursos->links()); ?>

            </div>

        </div>
        <div class="card-footer"></div>
    </div>
    <!-- Modal -->
    <div wire:ignore class="modal fade" id="modalCurso" tabindex="-1" aria-labelledby="modalCursoLabel"
        aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEstadoPagoLabel">FORMULARIO DE REGISTRO</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        wire:click="resetear"></button>
                </div>

                <div class="modal-body">

                    <div class="row">
                        <div class="col-4 mb-2">
                            <label for="">NOMBRE</label>
                        </div>
                        <div class="col-8 mb-2">
                            <input type="text" class="form-control" wire:model.defer="nombre">

                        </div>
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="col-4 mb-2">
                            <label for="">NIVEL</label>
                        </div>
                        <div class="col-8 mb-2">
                            <?php echo Form::select('nivelcurso_id', $nivelcursos, $nivelcurso_id,
                            ['class'=>'form-select','placeholder'=>'Seleccione un Nivel','wire:model'=>'nivelcurso_id']); ?>

                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                        wire:click="resetear">Cerrar</button>
                    <button type="button" class="btn btn-primary store" wire:click="store"
                        data-bs-dismiss="modal">Registrar</button>
                    <button type="button" class="btn btn-primary update" data-bs-dismiss="modal"
                        wire:click="update">Guardar</button>
                </div>

            </div>
        </div>
    </div>
    <script>
        function update(){
        $('.store').addClass('d-none');
        $('.update').removeClass('d-none');
    }
    function store(){
        $('.store').removeClass('d-none');
        $('.update').addClass('d-none');
    }

    function eliminar(id){
        const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
            confirmButton: 'btn btn-success',
            cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
        title: 'Eliminar Curso!',
        text: "Esta seguro de realizar la operación?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'No, cancelar!',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.livewire.find('<?php echo e($_instance->id); ?>').emit('destroy',id);
        } else if (
            result.dismiss === Swal.DismissReason.cancel
        ) {
            swalWithBootstrapButtons.fire(
                'Operación cancelada',
                'No se modificó ningún registro',
                'error'
            )
        }
    })
    }
    </script>

    <?php $__env->startSection('js'); ?>
    <script>
        Livewire.on('alert', message =>{
        
        Swal.fire(
                'Excelente!',
                message,
                'success'
            );
    });
    </script>
    <?php $__env->stopSection(); ?>
</div><?php /**PATH C:\xampp\htdocs\rest\resources\views/livewire/cursos/cursos.blade.php ENDPATH**/ ?>