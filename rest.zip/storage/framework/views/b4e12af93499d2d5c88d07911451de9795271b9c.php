<?php $__env->startSection('template_title'); ?>
Empresas Registradas |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card ">
                <div class="card-header bg-primary text-white">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            LISTADO DE EMPRESAS
                        </span>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresas.create')): ?>
                        <div class="float-right">
                            <a href="<?php echo e(route('empresas.create')); ?>" class="btn btn-warning btn-sm float-right"
                                data-placement="left">
                                <i class="fas fa-plus"></i>
                                Nuevo
                            </a>
                        </div>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover dataTable">
                            <thead class="thead">
                                <tr>
                                    <th>ID</th>
                                    <th>RAZON SOCIAL</th>
                                    <th>TELÉFONO</th>
                                    <th>NIT</th>
                                    <th>ESTADO</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($empresa->id); ?></td>

                                    <td><?php echo e($empresa->razonsocial); ?></td>
                                    <td><?php echo e($empresa->telefono); ?></td>
                                    <td><?php echo e($empresa->nit); ?></td>
                                    <td>
                                        <?php if($empresa->estado): ?>
                                        <span class="badge bg-success">ACTIVO</span>
                                        <?php else: ?>
                                        <span class="badge bg-danger">INACTIVO</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-end">
                                        <div class="dropdown">
                                            <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                                id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                                Opciones
                                                <i class="fas fa-caret-right"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-dark"
                                                aria-labelledby="dropdownMenuButton1">
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('empresas.show',$empresa->id)); ?>" title="Ver">
                                                        <i class="fa fa-fw fa-eye"> Ver</i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresas.edit')): ?>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('empresas.edit',$empresa->id)); ?>"
                                                        title="Editar"><i class="fa fa-fw fa-edit"></i> Editar</a>
                                                    <?php endif; ?>
                                                </li>
                                                <li>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursales')): ?>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('sucursales',$empresa->id)); ?>"
                                                        title="Editar"><i class="fas fa-sitemap"></i> Sucursales</a>
                                                    <?php endif; ?>
                                                </li>
                                                <form action="<?php echo e(route('empresas.destroy',$empresa->id)); ?>" method="POST"
                                                    class="desactivar">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresas.destroy')): ?>
                                                        <?php if($empresa->estado): ?>
                                                        <button type="submit" class="dropdown-item btn btn-link"><i
                                                                class="fas fa-power-off" title="Desactivar"></i> Desactivar</button>
                                                        <?php else: ?>
                                                        <button type="submit" class="dropdown-item btn btn-link"><i
                                                                class="fas fa-power-off" title="Activar"></i> Activar</button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </form>
                                            </ul>
                                        </div>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/empresa/index.blade.php ENDPATH**/ ?>