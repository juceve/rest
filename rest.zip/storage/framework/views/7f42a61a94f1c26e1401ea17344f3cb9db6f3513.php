
<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow">
  <div class="card-header">
    <div class="row align-items-center">
      <div class="col">
        <h2 class="fs-5 fw-bold mb-0">Bienvenidos al Admin Rest</h2>
      </div>
      
    </div>
  </div>
  <div class="card-body">
   
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rest\resources\views/home.blade.php ENDPATH**/ ?>